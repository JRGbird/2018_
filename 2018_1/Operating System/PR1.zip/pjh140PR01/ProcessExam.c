#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <time.h>

int main(void)
{
	pid_t pid;								//현재 process의 pid를 받아올 pid_t형 변수 pid를 선언한다.

	int i;									//int형 변수 i선언
	int j;									//int형 변수 j선언
	time_t current_time;					//현재 시간 정보 값을 저장할 time_t형 변수 current_time선언

	printf("fork program starting\n");		//fork가 시작될 것이라는 문구를 출력한다.
	
	pid_t ppid;								//부모 프로세스의 pid값을 받아올 pid_t형 변수 ppid를 선언한다.
	ppid = getpid();						//이 시점의 프로세스의 pid값이 부모 프로세스의 pid값이다.
											//그 부모 프로세스의 pid값을 getpid함수를 사용하여 ppid에 저장한다.

	for(i=0; i<10; i++)						//fork를 10번 실행하기 위해 10번 반복하는 for문을 만든다.
		if(ppid==getpid())					//이 if문을 사용하여 만약 지금 실행되고 있는 process의 pid값이
											//부모 process이면 fork함수를 실행하고, 부모의 pid값이 아닌 다른
											//값이라면(fork함수로 인해 생긴 자식 process의 과정이라면 fork를
											//하지 않도록 한다.
			pid = fork();					//fork()함수를 실행하는 부분이다. 이 과정에서 생성되는 자식 프로세스의
											//pid가 변 pid에 저장된다.

	time(&current_time);					//time함수를 사용하여 현재 시간 정보를 받아온다. 

	switch(pid)								//현재 프로세스의 pid값이 0이면 자식 프로세스 이므로
											//case 0:의 코드가 실행되고
											//0이 아닌 다른 값이면(부모 프로세스이면)
											//derault의 코드가 실행되도록하는 switch함수이다.
	{
	case -1:
		perror("fork failed");				//fork가 실패했을 때 실패를 알려주는 코드이다.
		exit(1);
	case 0:
		for(j=0;j<100;j++){					//현재 프로세스의 pid값이 0인 자식 프로세스라면
											//현재 PID값, Count값, PPID(그 자식 프로세스의 부모
											//프로세스 PID값), 현재 시간 정보들을 100번씩 출력하게 한다.
		printf(" [PID = %d, Count #%d, PPID = %d]", getpid(), j, getppid());
		printf(" datetime = %s", ctime(&current_time));			
		}
		break;								
	default:
		for(i=0; i<10; i++){
			pid = wait(NULL);				//자식 프로세스가 종료될 때 까지 부모 프로세스를 대기하게 하는
											//wait함수를 사용한다. 자식 프로세스가 끝나면 그 프로세스의
											//(자식 프로세스)의 pid값을 받아와 pid변수에 저장한다. 
			printf("Child has finished: PID = %d\n",pid);		//저장한 pid값을 출력하며 자식 프로세스의
																//종료를 알린다.
																//10번 반복하는 for문이므로
																//자식 프로세스 10개가 끝날 때 까지
																//자식이 끝날 때 마다 pid값을
																//하나 씩 알려준다.
		}
		break;
	}

	return 0;
	
}
